<?php
/**
 * Plugin Name: Dima Installer
 * Description: A secure and efficient plugin to export and import WordPress data for custom installations. Dima Software Group All Right Reserved. https://www.dimagroup.ir
 * Version: 1.0
 * Author: R.Balvardi
 */

// جلوگیری از دسترسی مستقیم به فایل
if (!defined('ABSPATH')) {
    exit;
}

// تابع اصلی برای ایجاد منوی افزونه در داشبورد وردپرس
function dima_installer_menu() {
    add_menu_page(
        'Dima Installer', // عنوان صفحه
        'Dima Installer', // عنوان منو
        'manage_options',   // سطح دسترسی
        'dima-installer', // slug
        'dima_installer_page' // تابع نمایش صفحه
    );
}
add_action('admin_menu', 'dima_installer_menu');

// صفحه اصلی افزونه
function dima_installer_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

    ?>
    <div class="wrap">
        <h1>Dima Installer</h1>
        <p>Export or Import your WordPress data securely.</p>

        <!-- دکمه‌های Export -->
        <form method="post" enctype="multipart/form-data">
            <?php submit_button('Export Data as JSON', 'primary', 'export_json'); ?>
            <?php submit_button('Export Data as SQL', 'secondary', 'export_sql'); ?>
            <?php submit_button('Export Data as PHP', 'secondary', 'export_php'); ?>
            <br><br>
            <input type="file" name="import_file" />
            <?php submit_button('Import Data', 'secondary', 'import_data'); ?>
        </form>

        <?php
        if (isset($_POST['export_json'])) {
            dima_installer_export_data('json');
        }
        if (isset($_POST['export_sql'])) {
            dima_installer_export_data('sql');
        }
        if (isset($_POST['export_php'])) {
            dima_installer_export_data('php');
        }
        if (isset($_POST['import_data'])) {
            dima_installer_import_data();
        }
        ?>
    </div>
    <?php
}

// تابع Export داده‌ها
function dima_installer_export_data($format) {
    global $wpdb;

    // ذخیره تنظیمات عمومی
    $general_settings = array(
        'siteurl' => get_option('siteurl'),
        'home' => get_option('home'),
        'blogname' => get_option('blogname'),
        'blogdescription' => get_option('blogdescription'),
    );

    // ذخیره دسته‌بندی‌ها
    $categories = get_categories(array('hide_empty' => false));
    $category_data = array();
    foreach ($categories as $category) {
        $category_data[] = array(
            'name' => $category->name,
            'slug' => $category->slug,
        );
    }

    // ذخیره مطالب
    $posts = get_posts(array('numberposts' => -1));
    $post_data = array();
    foreach ($posts as $post) {
        $post_data[] = array(
            'title' => $post->post_title,
            'content' => $post->post_content,
            'categories' => wp_get_post_categories($post->ID, array('fields' => 'slugs')),
        );
    }

    // ذخیره محصولات (اگر WooCommerce فعال باشد)
    $products = array();
    if (class_exists('WooCommerce')) {
        $product_posts = get_posts(array('post_type' => 'product', 'numberposts' => -1));
        foreach ($product_posts as $product_post) {
            $product = wc_get_product($product_post->ID);
            $products[] = array(
                'name' => $product->get_name(),
                'price' => $product->get_price(),
                'categories' => wp_get_post_terms($product_post->ID, 'product_cat', array('fields' => 'slugs')),
                'description' => $product->get_description(),
            );
        }
    }

    // ذخیره ابزارها (Widgets)
    function dima_get_widgets_data() {
        $widgets = get_option('sidebars_widgets');
        $widget_data = array();
        foreach ($widgets as $sidebar_id => $widget_ids) {
            if (!is_array($widget_ids)) continue;
            foreach ($widget_ids as $widget_id) {
                $widget_type = preg_replace('/-[0-9]+$/', '', $widget_id);
                $widget_options = get_option('widget_' . $widget_type);
                if (isset($widget_options)) {
                    $widget_data[$sidebar_id][$widget_id] = $widget_options;
                }
            }
        }
        return $widget_data;
    }

    // ذخیره منوها (Menus)
    function dima_get_menus_data() {
        $menus = wp_get_nav_menus();
        $menu_data = array();
        foreach ($menus as $menu) {
            $menu_items = wp_get_nav_menu_items($menu->term_id);
            $items = array();
            foreach ($menu_items as $item) {
                $items[] = array(
                    'title' => $item->title,
                    'url' => $item->url,
                    'menu_order' => $item->menu_order,
                    'parent' => $item->menu_item_parent,
                );
            }
            $menu_data[$menu->slug] = $items;
        }
        return $menu_data;
    }

    // تجمیع داده‌ها
    $data = array(
        'settings' => $general_settings,
        'categories' => $category_data,
        'posts' => $post_data,
        'products' => $products,
        'widgets' => dima_get_widgets_data(), // اضافه کردن ابزارها
        'menus' => dima_get_menus_data(),    // اضافه کردن منوها
    );

    // تولید خروجی بر اساس فرمت
    switch ($format) {
        case 'json':
            $file_name = 'dima-installer-data-' . date('Y-m-d') . '.json';
            file_put_contents(WP_CONTENT_DIR . '/uploads/' . $file_name, json_encode($data, JSON_PRETTY_PRINT));
            zip_file(WP_CONTENT_DIR . '/uploads/' . $file_name, WP_CONTENT_DIR . '/uploads/' . $file_name . '.zip');
            echo '<div class="notice notice-success"><p>Data exported successfully! File saved as ZIP.</p></div>';
            break;

        case 'sql':
            $sql_content = "-- Dima Installer SQL Export\n\n";
            foreach ($general_settings as $key => $value) {
                $sql_content .= "INSERT INTO {$wpdb->prefix}options (option_name, option_value) VALUES ('$key', '$value') ON DUPLICATE KEY UPDATE option_value = VALUES(option_value);\n";
            }
            foreach ($category_data as $category) {
                $sql_content .= "INSERT INTO {$wpdb->prefix}terms (name, slug) VALUES ('{$category['name']}', '{$category['slug']}') ON DUPLICATE KEY UPDATE name = VALUES(name);\n";
            }
            foreach ($post_data as $post) {
                $sql_content .= "INSERT INTO {$wpdb->prefix}posts (post_title, post_content, post_status, post_type) VALUES ('{$post['title']}', '{$post['content']}', 'publish', 'post');\n";
            }
            $file_name = 'dima-installer-data-' . date('Y-m-d') . '.sql';
            file_put_contents(WP_CONTENT_DIR . '/uploads/' . $file_name, $sql_content);
            zip_file(WP_CONTENT_DIR . '/uploads/' . $file_name, WP_CONTENT_DIR . '/uploads/' . $file_name . '.zip');
            echo '<div class="notice notice-success"><p>SQL Data exported successfully! File saved as ZIP.</p></div>';
            break;

        case 'php':
            $php_content = "<?php\nif (!defined('ABSPATH')) { exit; }\nfunction dima_import_data() {\n";
            foreach ($general_settings as $key => $value) {
                $php_content .= "update_option('$key', '$value');\n";
            }
            foreach ($category_data as $category) {
                $php_content .= "wp_insert_term('{$category['name']}', 'category', array('slug' => '{$category['slug']}'));\n";
            }
            foreach ($post_data as $post) {
                $php_content .= "\$post_id = wp_insert_post(array('post_title' => '{$post['title']}', 'post_content' => '{$post['content']}', 'post_status' => 'publish', 'post_type' => 'post'));\n";
                $php_content .= "wp_set_post_categories(\$post_id, " . var_export($post['categories'], true) . ");\n";
            }
            $php_content .= "}\n";
            $file_name = 'dima-installer-data-' . date('Y-m-d') . '.php';
            file_put_contents(WP_CONTENT_DIR . '/uploads/' . $file_name, $php_content);
            zip_file(WP_CONTENT_DIR . '/uploads/' . $file_name, WP_CONTENT_DIR . '/uploads/' . $file_name . '.zip');
            echo '<div class="notice notice-success"><p>PHP Data exported successfully! File saved as ZIP.</p></div>';
            break;
    }
}

// فشرده‌سازی فایل‌ها
function zip_file($source, $destination) {
    $zip = new ZipArchive();
    if ($zip->open($destination, ZipArchive::CREATE) === true) {
        $zip->addFile($source, basename($source));
        $zip->close();
        unlink($source); // حذف فایل اصلی
    }
}

// تابع Import داده‌ها
function dima_installer_import_data() {
    if ($_FILES['import_file']['error'] === UPLOAD_ERR_OK) {
        $file_info = pathinfo($_FILES['import_file']['name']);
        $allowed_extensions = ['json', 'sql', 'php'];
        if (!in_array(strtolower($file_info['extension']), $allowed_extensions)) {
            echo '<div class="notice notice-error"><p>Error: Invalid file type!</p></div>';
            return;
        }

        $file_path = $_FILES['import_file']['tmp_name'];

        switch ($file_info['extension']) {
            case 'json':
                $data = json_decode(file_get_contents($file_path), true);
                if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
                    echo '<div class="notice notice-error"><p>Error: Invalid JSON file!</p></div>';
                    return;
                }

                // Import settings
                if (isset($data['settings']) && is_array($data['settings'])) {
                    foreach ($data['settings'] as $key => $value) {
                        update_option($key, $value);
                    }
                } else {
                    echo '<div class="notice notice-error"><p>Error: Settings data is missing or invalid!</p></div>';
                }

                // Import categories
                if (isset($data['categories']) && is_array($data['categories'])) {
                    foreach ($data['categories'] as $category) {
                        wp_insert_term($category['name'], 'category', array('slug' => $category['slug']));
                    }
                }

                // Import posts
                if (isset($data['posts']) && is_array($data['posts'])) {
                    foreach ($data['posts'] as $post_data) {
                        $post_id = wp_insert_post(array(
                            'post_title' => $post_data['title'],
                            'post_content' => $post_data['content'],
                            'post_status' => 'publish',
                            'post_type' => 'post',
                        ));
                        wp_set_post_categories($post_id, $post_data['categories']);
                    }
                }

                // Import widgets
                if (isset($data['widgets']) && is_array($data['widgets'])) {
                    dima_restore_widgets($data['widgets']);
                }

                // Import menus
                if (isset($data['menus']) && is_array($data['menus'])) {
                    dima_restore_menus($data['menus']);
                }

                echo '<div class="notice notice-success"><p>Data imported successfully!</p></div>';
                break;

            case 'sql':
                dima_execute_sql($file_path);
                break;

            case 'php':
                include $file_path;
                if (function_exists('dima_import_data')) {
                    dima_import_data();
                    echo '<div class="notice notice-success"><p>PHP Data imported successfully!</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>Error: Invalid PHP file!</p></div>';
                }
                break;
        }
    } else {
        echo '<div class="notice notice-error"><p>Error uploading file!</p></div>';
    }
}

// Restore ابزارها (Widgets)
function dima_restore_widgets($widgets_data) {
    foreach ($widgets_data as $sidebar_id => $widgets) {
        $sidebar_widgets = array();
        foreach ($widgets as $widget_id => $widget_options) {
            $widget_type = preg_replace('/-[0-9]+$/', '', $widget_id);
            $widget_number = substr($widget_id, strrpos($widget_id, '-') + 1);
            $current_options = get_option('widget_' . $widget_type, array());
            $current_options[$widget_number] = $widget_options;
            update_option('widget_' . $widget_type, $current_options);
            $sidebar_widgets[] = $widget_id;
        }
        $sidebars_widgets = get_option('sidebars_widgets', array());
        $sidebars_widgets[$sidebar_id] = $sidebar_widgets;
        update_option('sidebars_widgets', $sidebars_widgets);
    }
}

// Restore منوها (Menus)
function dima_restore_menus($menus_data) {
    foreach ($menus_data as $menu_slug => $menu_items) {
        $menu_exists = wp_get_nav_menu_object($menu_slug);
        if (!$menu_exists) {
            $menu_id = wp_create_nav_menu($menu_slug);
        } else {
            $menu_id = $menu_exists->term_id;
        }

        foreach ($menu_items as $item) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' => $item['title'],
                'menu-item-url' => $item['url'],
                'menu-item-position' => $item['menu_order'],
                'menu-item-parent-id' => $item['parent'],
                'menu-item-status' => 'publish',
            ));
        }
    }
}

// اجرای فایل SQL
function dima_execute_sql($file_path) {
    global $wpdb;
    $sql = file_get_contents($file_path);
    $queries = explode(';', $sql);
    foreach ($queries as $query) {
        if (!empty(trim($query))) {
            $wpdb->query($query);
        }
    }
    echo '<div class="notice notice-success"><p>SQL Data imported successfully!</p></div>';
}

// Backup خودکار دیتابیس
function dima_backup_database() {
    global $wpdb;
    $tables = $wpdb->get_col("SHOW TABLES");
    $backup_file = WP_CONTENT_DIR . '/uploads/dima-backup-' . date('Y-m-d') . '.sql';
    $handle = fopen($backup_file, 'w');
    foreach ($tables as $table) {
        $rows = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);
        fwrite($handle, "DROP TABLE IF EXISTS $table;\n");
        $create_table = $wpdb->get_row("SHOW CREATE TABLE $table", ARRAY_N);
        fwrite($handle, $create_table[1] . ";\n");
        foreach ($rows as $row) {
            $values = array_map(function ($value) {
                return "'" . esc_sql($value) . "'";
            }, $row);
            fwrite($handle, "INSERT INTO $table VALUES (" . implode(',', $values) . ");\n");
        }
    }
    fclose($handle);
    echo '<div class="notice notice-success"><p>Database backup created successfully!</p></div>';
}